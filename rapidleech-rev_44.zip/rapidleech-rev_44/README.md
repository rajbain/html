## Disclaimer

### This project is forked from the official repo to allow other users to maintain it as the original repo is now read-only.

This original project is no longer maintained and we are looking for maintainers.

If you are willing to become a maintainer you can send an email to ept6f5mugkd3 [at] opayq [dot] com

# Rapidleech

[![GitHub last commit](https://img.shields.io/github/last-commit/SSoft7/rapidleech?label=last%20update)](https://github.com/SSoft7/rapidleech/commits/master)
[![Support Forum](https://img.shields.io/badge/Support%20Forum-Click%20Here-blue)](https://rapidleech.com/forum/)

Rapid Leech is a free server transfer script for use on various popular upload/download sites such as uploaded.net, Rapidgator.net and more than 127 others. The famous Rapidleech script transfers files from Other Filehosting Servers To Your Server via your fast servers connection speed and dumps the file on your server. You may then download these files from your server anytime later.

Rapidleech script has being used by more than 5 million users worldwide and has being installed on more than 2000 servers.
For webmasters, if you have not tried the script before, download and install now and you will see how convenient the script can be. You may also generate income by offering your Rapidleech sites to end-users and earn income from advertising programs. Some webmasters are earning hundreds per day on the advertising program(Google and yahoo Ads) from their Rapidleech sites. Script installation is extremely easy and does not require any database.

For end-users, you may search on our forum for readily available installed scripts on servers worldwide. You may use them but please support these sites by visiting their sponsors or donate in order to keep these sites available.
