<?php
$upload_services[] = 'minhateca.com.br';
$max_file_size['minhateca.com.br'] = 0;
$page_upload['minhateca.com.br'] = 'minhateca.com.br.php';
?>
