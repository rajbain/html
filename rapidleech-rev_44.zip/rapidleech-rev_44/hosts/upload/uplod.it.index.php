<?php
$upload_services[] = 'uplod.it';
$max_file_size['uplod.it'] = false;
$page_upload['uplod.it'] = 'uplod.it.php';  
?>