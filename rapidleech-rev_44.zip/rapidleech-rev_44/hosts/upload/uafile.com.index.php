<?php
$upload_services[]="uafile.com";
$max_file_size["uafile.com"]=750;
$page_upload["uafile.com"] = "uafile.com.php";  
?>