<?php
$upload_services[]="nippyshare.com";
$max_file_size["nippyshare.com"]=100;
$page_upload["nippyshare.com"] = "nippyshare.com.php";  
?>