<?php
$upload_services[] = 'tusfiles.net';
$max_file_size['tusfiles.net'] = false;
$page_upload['tusfiles.net'] = 'tusfiles.net.php';  
?>