<?php
$upload_services[] = 'usersfiles.com';
$max_file_size['usersfiles.com'] = 2048;
$page_upload['usersfiles.com'] = 'usersfiles.com.php';
?>
