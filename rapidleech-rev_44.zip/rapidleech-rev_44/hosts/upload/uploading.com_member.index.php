<?php
$upload_services[] = 'uploading.com_member';
$max_file_size['uploading.com_member'] = 2000;
$page_upload['uploading.com_member'] = 'uploading.com_member.php';
?>