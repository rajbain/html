<?php
$upload_services[]="uptotal.com_member";
$max_file_size["uptotal.com_member"]=999;
$page_upload["uptotal.com_member"] = "uptotal.com_member.php";  
?>