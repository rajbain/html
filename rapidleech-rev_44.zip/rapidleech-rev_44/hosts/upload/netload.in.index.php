<?php 
$upload_services[] = "netload.in";
$max_file_size["netload.in"] = 400;
$page_upload["netload.in"] = "netload.in.php";
?>