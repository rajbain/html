<?php
$upload_services[] = 'br2share.net';
$max_file_size['br2share.net'] = 2048;
$page_upload['br2share.net'] = 'br2share.net.php';  
?>