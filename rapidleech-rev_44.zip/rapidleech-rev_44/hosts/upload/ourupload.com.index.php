<?php
$upload_services[] = 'ourupload.com';
$max_file_size['ourupload.com'] = 5000; // Filesize limit (MB)
$page_upload['ourupload.com'] = 'ourupload.com.php';